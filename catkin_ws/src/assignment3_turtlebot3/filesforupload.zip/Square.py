#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
import math
import time
import numpy as np

def move():
    # Starts a new node
    rospy.init_node('robot_cleaner', anonymous=True)
    velocity_publisher = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    vel_msg = Twist()

    #Setting conditions
    linear_speed = 0.2
    angular_speed = 0.2
    distance = 2
    current_distance = 0
    current_angle = 0
    angle = np.radians(90)
    counter = 1

    while counter <= 4:

        #Setting the current time for distance calculus
        t0 = rospy.Time.now().to_sec()

        while(current_distance <= distance):
            current_angle = 0
            vel_msg.angular.z = 0
            vel_msg.linear.x = linear_speed
            velocity_publisher.publish(vel_msg)
            t2=rospy.Time.now().to_sec()
            current_distance= linear_speed*(t1-t0) 
        
        while(current_angle <= angle):
            current_distance = 0
            vel_msg.linear.x = 0
            vel_msg.angular.z = angular_speed
            velocity_publisher.publish(vel_msg)
            t1=rospy.Time.now().to_sec()
            current_angle= angular_speed*(t2-t1)

        t0 = rospy.Time.now().to_sec()
        counter = counter + 1

    vel_msg.linear.x = 0
    vel_msg.angular.z = 0
    velocity_publisher.publish(vel_msg)

if __name__ == '__main__':
    try:
        #Testing our function
        move()
    except rospy.ROSInterruptException: pass
