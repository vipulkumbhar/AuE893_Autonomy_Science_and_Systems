Team Name: TMNT (Teenage Mutant Ninja Turtles)
Team Number: 03
Team Members: 	Akshay Mahajan
		Ashit Mohanty
		Manu Srivastava
		Siddesh Bagkar
		Vipul Kumbhar		
Assignment 3

Launch Files

(1) Part 1:
	Launch file name: move.launch
	
	-This launch file first initializes the type of turtlebot. Here it has a default entry of burger. Next the initial coordinates of the turtlebot have been defined.
	 Next set of commands launch the empty.world file in gazebo and the dynamic parameters of the virtual world have been initialized. 
	
	-A variable has been declared with name 'code' that has been initialized as square and can accept arguments as 'square' to run Square.py and 'circle' to run Circle.py. Based on the 		 input the respective command is executed giving reference to the package name and file name i.e. Square.py or Circle.py.
	
	The commands that need to be executed in the terminal are as follows:
	$roslaunch assignment3_turtlebot3 move.launch code:= square #for running square.py
	$roslaunch assignment3_turtlebot3 move.launch code:= cicrle #for running circle.py

(1) Part 2:
	Launch file name: turtlebot3_wall.launch
	
	-This launch file first initializes the type of turtlebot. Here it has a default entry of burger. Next the initial coordinates of the turtlebot have been defined.
	-A world in gazebo has been created with a single wall facing the turtlebot and the dynamic parameters of the virtual world have been initialized.
	-Next the command is executed to run the file wall.py and execute the "emergency braking" maneuver giving reference to package name and file name i.e. wall.py.

	The commands that need to be executed in the terminal are as follows:
	$roslaunch assignment3_turtlebot3 turtlebot3_wall.launch #for running wall.py

Work Distribution

Vipul Kumbhar 	: Recording Videos and writing README.md
Akshay Mahajan	: Creating move.launch file
Ashit Mohanty 	: Emergency Braking Maneuver python code
Manu Srivastava	: Creating gazebo environment, modifying circle.py and square.py and pushing into repo.
Siddhesh Bagkar	: Creating turtlebot3_wall.launch file
